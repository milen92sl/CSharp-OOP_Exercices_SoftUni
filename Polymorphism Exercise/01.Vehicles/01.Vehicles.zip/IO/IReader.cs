﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles.IO
{
    public interface IReader
    {
        string CustomReadLine();
    }
}
