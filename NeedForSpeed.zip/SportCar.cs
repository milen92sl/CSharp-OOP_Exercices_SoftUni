﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class SportCar : Car
    {
        public SportCar(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }

        private const double DefaultSportCarFuelConsumption = 10;

        public override double FuelConsumption => DefaultSportCarFuelConsumption;

        public override void Drive(double km)
        {
            double fuelAfterDrive = Fuel - km * FuelConsumption;

            if (fuelAfterDrive >= 0)
            {
                Fuel = fuelAfterDrive;
            }
        }
    }
}
