﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skeleton.Tests
{
    public class FakeWeapon : IWeapon
    {
        public void Attack(ITarget target)
        {
        }

        public int AttackPoints => 10;
        public int DurabilityPoints => 10;
    }
}
