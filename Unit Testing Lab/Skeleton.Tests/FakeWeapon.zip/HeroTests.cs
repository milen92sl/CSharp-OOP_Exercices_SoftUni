﻿using NUnit.Framework;
using Skeleton;
using Skeleton.Tests;

[TestFixture]
public class HeroTests
{
    [Test]
    public void HeroGainsXpWhenTargetDies()
    {
        IWeapon weapon = new FakeWeapon();
        ITarget target = new FakeTarget();

        Hero hero = new Hero("Pesho", weapon);

        hero.Attack(target);

        Assert.That(hero.Experience, Is.EqualTo(10),
            "Hero does not gain XP when target dies");
    }
}