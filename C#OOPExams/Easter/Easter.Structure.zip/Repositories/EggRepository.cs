﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Easter.Models.Eggs.Contracts;
using Easter.Repositories.Contracts;

namespace Easter.Repositories
{
    public class EggRepository : IRepository<IEgg>
    {
        private ICollection<IEgg> models;

        public EggRepository()
        {
            this.models = new List<IEgg>();
        }

        public IReadOnlyCollection<IEgg> Models => (IReadOnlyCollection<IEgg>)this.models;
        public void Add(IEgg model) => models.Add(model);

        public bool Remove(IEgg model) => models.Remove(model);

        public IEgg FindByName(string name) => this.models.FirstOrDefault(x => x.Name == name);
    }
}
