using System;

namespace Computers.Tests
{
    using NUnit.Framework;

    public class ComputerTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void ConstructorPC_Setter_IsTheNameNullOrWhiteSpace(string name)
        {
            Computer computer = new Computer("Asd");

            Assert.Throws<ArgumentNullException>(() => computer = new Computer(name));
        }

        [Test]
        public void AddPartMethod_IfPartNameIsNullThrowsInvalidOperationExeption()
        {
            Part part = new Part(null, 23);
            Assert.That(null,Is.EqualTo(null), "Cannot add null!");
        }
    }
}