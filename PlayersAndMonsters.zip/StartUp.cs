﻿using System;
using System.Collections.Generic;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Dictionary<string, int> heroes = new Dictionary<string, int>();

            Hero hero = new Hero("Milen", 27);

            Wizard wizard = new Wizard("Pesho", 28);

            DarkKnight darkKnight = new DarkKnight("Gosho", 42);

            MuseElf museElf = new MuseElf("Alq", 30);

            BladeKnight bladeKnight = new BladeKnight("Strahil", 27);

            heroes.Add(hero.Username, hero.Level);
            heroes.Add(wizard.Username,wizard.Level);
            heroes.Add(darkKnight.Username, darkKnight.Level);
            heroes.Add(museElf.Username, museElf.Level);
            heroes.Add(bladeKnight.Username, bladeKnight.Level);

            foreach (var h in heroes)
            {
                Console.WriteLine(h);
            }
        }
    }
}